<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">
                <?php echo date('Y'); ?> &copy; <a href="">Diana Salinas</a>
            </div>
        </div>
    </div>
</footer>
</div>
</div>
<script src="<?php echo SITE_URL; ?>js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script src="<?php echo ADMIN_URL; ?>js/scripts.js"></script>
</body>

</html>